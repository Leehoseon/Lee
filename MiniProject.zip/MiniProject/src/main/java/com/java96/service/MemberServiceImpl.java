package com.java96.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java96.dto.MemberDTO;
import com.java96.mapper.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberMapper mapper;
	
	@Override
	public MemberDTO login(String uid) {

		MemberDTO dto = new MemberDTO();
		
		dto.setUid(dto.getUid());
		dto.setUpw(dto.getUpw());
		
		
		System.out.println(dto);
		return dto;
	}

	@Override
	public void register(MemberDTO dto) {
		
		mapper.register(dto);
		
	}

	
	
}
