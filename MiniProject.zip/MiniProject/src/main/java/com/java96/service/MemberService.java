package com.java96.service;

import com.java96.dto.MemberDTO;

public interface MemberService {

	public MemberDTO login(String uid);
	
	public void register(MemberDTO dto);
	
}
