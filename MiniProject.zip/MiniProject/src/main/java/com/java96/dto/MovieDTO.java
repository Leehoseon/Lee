package com.java96.dto;

import lombok.Data;

@Data
public class MovieDTO {

	private String title,writer;
	private int tno;
	
}
