package com.java96.web;

public class PushTest {

	
	public static void main(String[] args) {
		
		System.out.println("test~~~~");
		
	}
	
}
