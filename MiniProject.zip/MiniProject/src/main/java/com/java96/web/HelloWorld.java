package com.java96.web;

public class HelloWorld {
	
	public static void main(String[] args) {
		
		System.out.println("main");
		System.out.println("dodo");
	}

}
